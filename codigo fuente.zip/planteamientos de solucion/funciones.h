

#ifndef FUNCIONES_H
#define FUNCIONES_H

#define MAX_PRODUCTOS 100

struct Producto {
    char nombre[50];
    char marca[50];
    int cantidad;
    float precio;
    char proveedor[50];
    char ciudad[50];
    char pais[50];
};

struct Inventario {
    struct Producto productos[MAX_PRODUCTOS];
    int cantidadProductos;
};

void ingresarProducto(struct Inventario *inventario);

void editarProducto(struct Inventario *inventario);

void eliminarProducto(struct Inventario *inventario);

void listarProductos(struct Inventario inventario);

#endif /* FUNCIONES_H */
