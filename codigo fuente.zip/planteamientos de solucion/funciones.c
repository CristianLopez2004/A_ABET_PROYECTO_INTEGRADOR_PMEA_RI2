#include <stdio.h>
#include "funciones.h"

void ingresarProducto(struct Inventario *inventario) {
    if (inventario->cantidadProductos < MAX_PRODUCTOS) {
        struct Producto nuevoProducto;
        printf("Ingrese el nombre del producto: ");
        scanf("%s", nuevoProducto.nombre);
        printf("Ingrese la marca del producto: ");
        scanf("%s", nuevoProducto.marca);
        printf("Ingrese la cantidad disponible: ");
        scanf("%d", &nuevoProducto.cantidad);
        printf("Ingrese el precio del producto: ");
        scanf("%f", &nuevoProducto.precio);
        printf("Ingrese el proveedor del producto: ");
        scanf("%s", nuevoProducto.proveedor);
        printf("Ingrese la ciudad de llegada del producto: ");
        scanf("%s", nuevoProducto.ciudad);
        printf("Ingrese el país de llegada del producto: ");
        scanf("%s", nuevoProducto.pais);

        inventario->productos[inventario->cantidadProductos++] = nuevoProducto;
        printf("Producto ingresado exitosamente.\n");

        // Guardar producto en archivo
        FILE *archivo = fopen("productos.txt", "a");
        if (archivo != NULL) {
            fprintf(archivo, "Índice: %d\n", inventario->cantidadProductos - 1);
            fprintf(archivo, "Nombre: %s\n", nuevoProducto.nombre);
            fprintf(archivo, "Marca: %s\n", nuevoProducto.marca);
            fprintf(archivo, "Cantidad: %d\n", nuevoProducto.cantidad);
            fprintf(archivo, "Precio: %.2f\n", nuevoProducto.precio);
            fprintf(archivo, "Proveedor: %s\n", nuevoProducto.proveedor);
            fprintf(archivo, "Ciudad de llegada: %s\n", nuevoProducto.ciudad);
            fprintf(archivo, "País de llegada: %s\n\n", nuevoProducto.pais);
            fclose(archivo);
        } else {
            printf("No se pudo abrir el archivo para guardar el producto.\n");
        }
    } else {
        printf("El inventario está lleno. No es posible ingresar más productos.\n");
    }
}

void editarProducto(struct Inventario *inventario) {
    int indice;
    printf("Ingrese el índice del producto a editar: ");
    scanf("%d", &indice);

    if (indice >= 0 && indice < inventario->cantidadProductos) {
        struct Producto *producto = &inventario->productos[indice];
        printf("Ingrese el nuevo nombre del producto: ");
        scanf("%s", producto->nombre);
        printf("Ingrese la nueva marca del producto: ");
        scanf("%s", producto->marca);
        printf("Ingrese la nueva cantidad disponible: ");
        scanf("%d", &producto->cantidad);
        printf("Ingrese el nuevo precio del producto: ");
        scanf("%f", &producto->precio);
        printf("Ingrese el nuevo proveedor del producto: ");
        scanf("%s", producto->proveedor);
        printf("Ingrese la nueva ciudad de llegada del producto: ");
        scanf("%s", producto->ciudad);
        printf("Ingrese el nuevo país de llegada del producto: ");
        scanf("%s", producto->pais);

        printf("Producto editado exitosamente.\n");
    } else {
        printf("Índice inválido. No se encontró el producto.\n");
    }
}

void eliminarProducto(struct Inventario *inventario) {
    int indice;
    printf("Ingrese el índice del producto a eliminar: ");
    scanf("%d", &indice);

    if (indice >= 0 && indice < inventario->cantidadProductos) {
        for (int i = indice; i < inventario->cantidadProductos - 1; i++) {
            inventario->productos[i] = inventario->productos[i + 1];
        }
        inventario->cantidadProductos--;

        printf("Producto eliminado exitosamente.\n");
    } else {
        printf("Índice inválido. No se encontró el producto.\n");
    }
}

void listarProductos(struct Inventario inventario) {
    printf("Productos ingresados:\n");
    for (int i = 0; i < inventario.cantidadProductos; i++) {
        struct Producto producto = inventario.productos[i];
        printf("Índice: %d\n", i);
        printf("Nombre: %s\n", producto.nombre);
        printf("Marca: %s\n", producto.marca);
        printf("Cantidad: %d\n", producto.cantidad);
        printf("Precio: %.2f\n", producto.precio);
        printf("Proveedor: %s\n", producto.proveedor);
        printf("Ciudad de llegada: %s\n", producto.ciudad);
        printf("País de llegada: %s\n", producto.pais);
        printf("\n");
    }
}
