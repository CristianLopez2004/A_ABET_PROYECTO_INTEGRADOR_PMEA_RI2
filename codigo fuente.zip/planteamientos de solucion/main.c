#include <stdio.h>
#include "funciones.h"

int main() {
    struct Inventario inventario;
    inventario.cantidadProductos = 0;

    int opcion;
    do {
        printf("----- Sistema de Inventario -----\n");
        printf("1. Ingresar producto\n");
        printf("2. Editar producto\n");
        printf("3. Eliminar producto\n");
        printf("4. Listar productos\n");
        printf("0. Salir\n");
        printf("Ingrese una opción: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                ingresarProducto(&inventario);
                break;
            case 2:
                editarProducto(&inventario);
                break;
            case 3:
                eliminarProducto(&inventario);
                break;
            case 4:
                listarProductos(inventario);
                break;
            case 0:
                printf("Saliendo del sistema...\n");
                break;
            default:
                printf("Opción inválida. Intente nuevamente.\n");
                break;
        }

        printf("\n");
    } while (opcion != 0);

    return 0;
}
